// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant reason:default

#include "render_frame_observer_qt.h"

#include "components/web_cache/renderer/web_cache_impl.h"
#include "content/public/renderer/render_frame.h"
#include "third_party/blink/public/web/web_document_loader.h"

namespace QtWebEngineCore {

RenderFrameObserverQt::RenderFrameObserverQt(content::RenderFrame *render_frame, web_cache::WebCacheImpl *web_cache_impl)
    : RenderFrameObserver(render_frame)
    , RenderFrameObserverTracker<RenderFrameObserverQt>(render_frame)
    , m_isFrameDetached(false)
    , m_web_cache_impl(web_cache_impl)
{}

RenderFrameObserverQt::~RenderFrameObserverQt() {}

void RenderFrameObserverQt::OnDestruct()
{
    delete this;
}

bool RenderFrameObserverQt::OnAssociatedInterfaceRequestForFrame(const std::string &interface_name,
                                                                 mojo::ScopedInterfaceEndpointHandle *handle)
{
    return m_associated_interfaces.TryBindInterface(interface_name, handle);
}

void RenderFrameObserverQt::WillDetach(blink::DetachReason reason)
{
    m_isFrameDetached = true;
}

bool RenderFrameObserverQt::isFrameDetached() const
{
    return m_isFrameDetached;
}

void RenderFrameObserverQt::ReadyToCommitNavigation(blink::WebDocumentLoader *)
{
    if (render_frame()->IsMainFrame() && m_web_cache_impl)
        m_web_cache_impl->ExecutePendingClearCache();
}

} // namespace QtWebEngineCore
