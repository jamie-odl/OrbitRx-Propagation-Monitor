// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant reason:default

#include "profile_adapter.h"

#include "base/files/file_util.h"
#include "base/strings/stringprintf.h"
#include "base/task/cancelable_task_tracker.h"
#include "base/threading/thread_restrictions.h"
#include "base/version_info/version_info.h"
#include "components/embedder_support/user_agent_utils.h"
#include "components/favicon/core/favicon_service.h"
#include "components/history/content/browser/history_database_helper.h"
#include "components/history/core/browser/history_database_params.h"
#include "components/history/core/browser/history_service.h"
#include "content/browser/web_contents/web_contents_impl.h"
#include "content/public/browser/browser_thread.h"
#include "content/public/browser/browsing_data_remover.h"
#include "content/public/browser/download_manager.h"
#include "content/public/browser/storage_partition.h"
#include "services/network/public/mojom/network_context.mojom.h"
#include "url/url_util.h"

#include "api/qwebengineextensionmanager.h"
#include "api/qwebengineurlscheme.h"
#include "content_browser_client_qt.h"
#include "download_manager_delegate_qt.h"
#include "favicon_driver_qt.h"
#include "favicon_service_factory_qt.h"
#include "permission_manager_qt.h"
#include "profile_adapter_client.h"
#include "profile_io_data_qt.h"
#include "profile_qt.h"
#include "renderer_host/user_resource_controller_host.h"
#include "type_conversion.h"
#include "visited_links_manager_qt.h"
#include "web_contents_adapter.h"
#include "web_contents_adapter_client.h"
#include "web_contents_delegate_qt.h"
#include "web_engine_context.h"

#include <QCoreApplication>
#include <QDir>
#include <QJsonObject>
#include <QSet>
#include <QString>
#include <QStandardPaths>

using namespace Qt::StringLiterals;

namespace {
inline QString buildLocationFromStandardPath(const QString &standardPath, const QString &name) {
    QString location;
    location += standardPath;
    if (location.isEmpty())
        location += QDir::homePath() % "/."_L1 % QCoreApplication::applicationName();

    location += "/QtWebEngine/"_L1 % name;
    return location;
}

void PopulateBrandVersionLists(const QJsonObject &fullVersionList,
                               blink::UserAgentMetadata &userAgentMetadata)
{
    userAgentMetadata.brand_version_list.clear();
    userAgentMetadata.brand_full_version_list.clear();

    for (const QString &key : fullVersionList.keys()) {
        std::string version = fullVersionList.value(key).toString().toStdString();
        userAgentMetadata.brand_full_version_list.push_back({ key.toStdString(), version });
        version = version.substr(0, version.find('.'));
        userAgentMetadata.brand_version_list.push_back({ key.toStdString(), version });
    }

    // Shuffle the lists
    int permutations = 1;
    for (int i = 2; i <= fullVersionList.size(); i++)
        permutations *= i;
    // We keep the brand lists identical throughout the lifetime of each major version of Chromium.
    permutations = version_info::GetMajorVersionNumberAsInt() % permutations;
    auto compare = [](blink::UserAgentBrandVersion &a, blink::UserAgentBrandVersion &b) {
        return a.brand + a.version < b.brand + b.version;
    };
    for (int i = 0; i < permutations; i++) {
        std::next_permutation(userAgentMetadata.brand_version_list.begin(),
                              userAgentMetadata.brand_version_list.end(), compare);
        std::next_permutation(userAgentMetadata.brand_full_version_list.begin(),
                              userAgentMetadata.brand_full_version_list.end(), compare);
    }
}
}

namespace QtWebEngineCore {

ProfileAdapter::ProfileAdapter(const QString &storageName, const QString &dataPath,
                               const QString &cachePath, HttpCacheType httpCacheType,
                               PersistentCookiesPolicy persistentCookiesPolicy,
                               int httpCacheMaximumSize,
                               PersistentPermissionsPolicy persistentPermissionPolicy
#if QT_CONFIG(ssl)
                               ,
                               const QList<QSslCertificate> &additionalTrustedCertificates
#endif
                               )
    : m_name(storageName)
    , m_offTheRecord(storageName.isEmpty())
    , m_dataPath(dataPath.isEmpty() && !m_name.isEmpty()
                         ? buildLocationFromStandardPath(QStandardPaths::writableLocation(
                                                                 QStandardPaths::AppDataLocation),
                                                         m_name)
                         : dataPath)
    , m_downloadPath(QStandardPaths::writableLocation(QStandardPaths::DownloadLocation))
    , m_cachePath(cachePath.isEmpty() && !m_name.isEmpty()
                          ? buildLocationFromStandardPath(
                                    QStandardPaths::writableLocation(QStandardPaths::CacheLocation),
                                    m_name)
                          : cachePath)
    , m_httpCacheType(httpCacheType)
    , m_persistentCookiesPolicy(persistentCookiesPolicy)
    , m_persistentPermissionsPolicy(persistentPermissionPolicy)
    , m_visitedLinksPolicy(TrackVisitedLinksOnDisk)
#if QT_CONFIG(ssl)
    , m_additionalTrustedCertificates(additionalTrustedCertificates)
#endif
    , m_clientHintsEnabled(true)
    , m_pushServiceEnabled(false)
    , m_httpCacheMaxSize(m_name.isEmpty() ? 0 : httpCacheMaximumSize)
{
    WebEngineContext::current()->addProfileAdapter(this);
    // creation of profile requires webengine context
    m_profile.reset(new ProfileQt(this));
    // initialize permissions store
    profile()->GetPermissionControllerDelegate();
    // fixme: this should not be here
    m_profile->m_profileIOData->initializeOnUIThread();
    m_customUrlSchemeHandlers.insert(QByteArrayLiteral("qrc"), &m_qrcHandler);
    m_cancelableTaskTracker.reset(new base::CancelableTaskTracker());

#if QT_CONFIG(webengine_extensions)
    m_extensionManager.reset(new QWebEngineExtensionManager(m_profile->extensionManager()));
#endif
    m_profile->DoFinalInit();
}

ProfileAdapter::~ProfileAdapter()
{
    m_cancelableTaskTracker->TryCancelAll();
    m_profile->NotifyWillBeDestroyed();
    releaseAllWebContentsAdapterClients();

    WebEngineContext::current()->removeProfileAdapter(this);
    if (m_downloadManagerDelegate) {
        m_profile->GetDownloadManager()->Shutdown();
        m_downloadManagerDelegate.reset();
    }
#if QT_CONFIG(ssl)
    delete m_clientCertificateStore;
    m_clientCertificateStore = nullptr;
#endif
    WebEngineContext::flushMessages();
}

void ProfileAdapter::setStorageName(const QString &storageName)
{
    if (storageName == m_name)
        return;
    m_name = storageName;
    if (!m_offTheRecord) {
        m_profile->setupPrefService();
        m_profile->setupPermissionsManager();
        if (!m_profile->m_profileIOData->isClearHttpCacheInProgress())
            m_profile->m_profileIOData->resetNetworkContext();
        if (m_visitedLinksManager)
            resetVisitedLinksManager();

        reinitializeHistoryService();
    }
}

void ProfileAdapter::setOffTheRecord(bool offTheRecord)
{
    if (offTheRecord == m_offTheRecord)
        return;
    m_offTheRecord = offTheRecord;
    m_profile->setupPrefService();
    m_profile->setupPermissionsManager();
    if (!m_profile->m_profileIOData->isClearHttpCacheInProgress())
        m_profile->m_profileIOData->resetNetworkContext();
    if (m_visitedLinksManager)
        resetVisitedLinksManager();

    if (offTheRecord) {
        favicon::FaviconService *faviconService =
                FaviconServiceFactoryQt::GetForBrowserContext(m_profile.data());
        faviconService->SetHistoryService(nullptr);
    } else if (!m_name.isEmpty()) {
        reinitializeHistoryService();
    }
}

ProfileQt *ProfileAdapter::profile()
{
    return m_profile.data();
}

bool ProfileAdapter::ensureDataPathExists()
{
    Q_ASSERT(!m_offTheRecord);
    base::ScopedAllowBlocking allowBlock;
    const base::FilePath &path = toFilePath(dataPath());
    if (path.empty())
        return false;
    if (base::DirectoryExists(path))
        return true;

    base::File::Error error;
    if (base::CreateDirectoryAndGetError(path, &error))
        return true;

    std::string errorstr = base::File::ErrorToString(error);
    qWarning("Cannot create directory %s. Error: %s.", path.AsUTF8Unsafe().c_str(),
             errorstr.c_str());
    return false;
}

VisitedLinksManagerQt *ProfileAdapter::visitedLinksManager()
{
    if (!m_visitedLinksManager)
        resetVisitedLinksManager();
    return m_visitedLinksManager.data();
}

DownloadManagerDelegateQt *ProfileAdapter::downloadManagerDelegate()
{
    if (!m_downloadManagerDelegate)
        m_downloadManagerDelegate.reset(new DownloadManagerDelegateQt(this));
    return m_downloadManagerDelegate.data();
}

QWebEngineCookieStore *ProfileAdapter::cookieStore()
{
    if (!m_cookieStore)
        m_cookieStore.reset(new QWebEngineCookieStore);
    return m_cookieStore.data();
}

QWebEngineUrlRequestInterceptor *ProfileAdapter::requestInterceptor()
{
    return m_requestInterceptor.data();
}

void ProfileAdapter::setRequestInterceptor(QWebEngineUrlRequestInterceptor *interceptor)
{
    m_requestInterceptor = interceptor;
}

void ProfileAdapter::addClient(ProfileAdapterClient *adapterClient)
{
    m_clients.append(adapterClient);
}

void ProfileAdapter::removeClient(ProfileAdapterClient *adapterClient)
{
    m_clients.removeOne(adapterClient);
}

bool ProfileAdapter::cancelDownload(quint32 downloadId)
{
    return downloadManagerDelegate()->cancelDownload(downloadId);
}

void ProfileAdapter::pauseDownload(quint32 downloadId)
{
    downloadManagerDelegate()->pauseDownload(downloadId);
}

void ProfileAdapter::resumeDownload(quint32 downloadId)
{
    downloadManagerDelegate()->resumeDownload(downloadId);
}

void ProfileAdapter::removeDownload(quint32 downloadId)
{
    downloadManagerDelegate()->removeDownload(downloadId);
}

void ProfileAdapter::acceptDownload(quint32 downloadId, bool accepted, bool useDownloadTargetCallback,
                                    const QString &path, int savePageFormat)
{
    if (useDownloadTargetCallback)
        downloadManagerDelegate()->downloadTargetDetermined(downloadId, accepted, path);
    else
        downloadManagerDelegate()->savePathDetermined(downloadId, accepted, path, savePageFormat);
}

ProfileAdapter *ProfileAdapter::createDefaultProfileAdapter()
{
    return WebEngineContext::current()->createDefaultProfileAdapter();
}

bool ProfileAdapter::profileExistOnPath(const QString &dataPath)
{
    return WebEngineContext::current()->profileExistOnPath(dataPath);
}

ProfileAdapter *ProfileAdapter::defaultProfileAdapter()
{
    WebEngineContext *context = WebEngineContext::current();
    return context ? context->defaultProfileAdapter() : nullptr;
}

QObject* ProfileAdapter::globalQObjectRoot()
{
    return WebEngineContext::current()->globalQObject();
}

QString ProfileAdapter::dataPath() const
{
    if (!m_dataPath.isEmpty())
        return m_dataPath;
    // And off-the-record or memory-only profile should not write to disk
    // but Chromium often creates temporary directories anyway, so given them
    // a location to do so.
    QString name = m_name;
    if (m_offTheRecord)
        name = u"OffTheRecord"_s;
    else if (m_name.isEmpty())
        name = u"UnknownProfile"_s;
    return buildLocationFromStandardPath(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation), name);
}

void ProfileAdapter::setDataPath(const QString &path)
{
    if (m_dataPath == path)
        return;
    m_dataPath = path;
    m_profile->setupPrefService();
    m_profile->setupPermissionsManager();
    m_profile->setupStoragePath();
    if (!m_profile->m_profileIOData->isClearHttpCacheInProgress())
        m_profile->m_profileIOData->resetNetworkContext();
    if (!m_offTheRecord && m_visitedLinksManager)
        resetVisitedLinksManager();

    if (!m_offTheRecord)
        reinitializeHistoryService();
}

void ProfileAdapter::setDownloadPath(const QString &path)
{
    m_downloadPath = path.isEmpty() ? QStandardPaths::writableLocation(QStandardPaths::DownloadLocation) : path;
}

QString ProfileAdapter::cachePath() const
{
    if (m_offTheRecord)
        return QString();
    if (!m_cachePath.isEmpty())
        return m_cachePath;
    if (!m_name.isNull())
        return buildLocationFromStandardPath(QStandardPaths::writableLocation(QStandardPaths::CacheLocation), m_name);
    return QString();
}

void ProfileAdapter::setCachePath(const QString &path)
{
    if (m_cachePath == path)
        return;
    m_cachePath = path;
    if (!m_offTheRecord && !m_profile->m_profileIOData->isClearHttpCacheInProgress())
        m_profile->m_profileIOData->resetNetworkContext();
}

QString ProfileAdapter::httpCachePath() const
{
    if (m_offTheRecord)
        return QString();
    const QString basePath = cachePath();
    if (!basePath.isEmpty())
        return basePath % "/Cache"_L1;
    return QString();
}

QString ProfileAdapter::httpUserAgent() const
{
    if (m_httpUserAgent.isNull())
        return QString::fromStdString(ContentBrowserClientQt::getUserAgent());
    return m_httpUserAgent;
}

void ProfileAdapter::setHttpUserAgent(const QString &userAgent)
{
    const QString httpUserAgent = userAgent.simplified();
    if (m_httpUserAgent == httpUserAgent)
        return;
    m_httpUserAgent = httpUserAgent;
    const std::string stdUserAgent = httpUserAgent.toStdString();

    std::vector<content::WebContentsImpl *> list = content::WebContentsImpl::GetAllWebContents();
    for (content::WebContentsImpl *web_contents : list)
        if (web_contents->GetBrowserContext() == m_profile.data()) {
            auto userAgentOverride = blink::UserAgentOverride::UserAgentOnly(stdUserAgent);
            userAgentOverride.ua_metadata_override = m_profile->m_userAgentMetadata;
            web_contents->SetUserAgentOverride(userAgentOverride, true);
        }

    m_profile->ForEachLoadedStoragePartition(
            [stdUserAgent](content::StoragePartition *storage_partition) {
                storage_partition->GetNetworkContext()->SetUserAgent(stdUserAgent);
            });
}

ProfileAdapter::HttpCacheType ProfileAdapter::httpCacheType() const
{
    if (m_httpCacheType == NoCache)
        return NoCache;
    if (isOffTheRecord() || httpCachePath().isEmpty())
        return MemoryHttpCache;
    return m_httpCacheType;
}

void ProfileAdapter::setHttpCacheType(ProfileAdapter::HttpCacheType newhttpCacheType)
{
    ProfileAdapter::HttpCacheType oldCacheType = httpCacheType();
    m_httpCacheType = newhttpCacheType;
    if (oldCacheType == httpCacheType())
        return;
    if (!m_offTheRecord && !m_profile->m_profileIOData->isClearHttpCacheInProgress()) {
        m_profile->m_profileIOData->resetNetworkContext();
    }
}

ProfileAdapter::PersistentCookiesPolicy ProfileAdapter::persistentCookiesPolicy() const
{
    if (isOffTheRecord() || m_name.isEmpty())
        return NoPersistentCookies;
    return m_persistentCookiesPolicy;
}

void ProfileAdapter::setPersistentCookiesPolicy(ProfileAdapter::PersistentCookiesPolicy newPersistentCookiesPolicy)
{
    ProfileAdapter::PersistentCookiesPolicy oldPolicy = persistentCookiesPolicy();
    m_persistentCookiesPolicy = newPersistentCookiesPolicy;
    if (oldPolicy == persistentCookiesPolicy())
        return;
    if (!m_offTheRecord && !m_profile->m_profileIOData->isClearHttpCacheInProgress())
        m_profile->m_profileIOData->resetNetworkContext();
}

ProfileAdapter::PersistentPermissionsPolicy ProfileAdapter::persistentPermissionsPolicy() const
{
    if (m_persistentPermissionsPolicy == PersistentPermissionsPolicy::AskEveryTime)
        return PersistentPermissionsPolicy::AskEveryTime;
    if (isOffTheRecord() || m_name.isEmpty())
        return PersistentPermissionsPolicy::StoreInMemory;
    return m_persistentPermissionsPolicy;
}

void ProfileAdapter::setPersistentPermissionsPolicy(ProfileAdapter::PersistentPermissionsPolicy newPersistentPermissionsPolicy)
{
    ProfileAdapter::PersistentPermissionsPolicy oldPolicy = persistentPermissionsPolicy();
    m_persistentPermissionsPolicy = newPersistentPermissionsPolicy;
    if (oldPolicy == persistentPermissionsPolicy())
        return;
    m_profile->setupPermissionsManager();
}

ProfileAdapter::VisitedLinksPolicy ProfileAdapter::visitedLinksPolicy() const
{
    if (isOffTheRecord() || m_visitedLinksPolicy == DoNotTrackVisitedLinks)
        return DoNotTrackVisitedLinks;
    if (m_name.isEmpty())
        return TrackVisitedLinksInMemory;
    return m_visitedLinksPolicy;
}

bool ProfileAdapter::trackVisitedLinks() const
{
    switch (visitedLinksPolicy()) {
    case DoNotTrackVisitedLinks:
        return false;
    default:
        break;
    }
    return true;
}

bool ProfileAdapter::persistVisitedLinks() const
{
    switch (visitedLinksPolicy()) {
    case DoNotTrackVisitedLinks:
    case TrackVisitedLinksInMemory:
        return false;
    default:
        break;
    }
    return true;
}

void ProfileAdapter::setVisitedLinksPolicy(ProfileAdapter::VisitedLinksPolicy visitedLinksPolicy)
{
    if (m_visitedLinksPolicy == visitedLinksPolicy)
        return;
    m_visitedLinksPolicy = visitedLinksPolicy;
    if (m_visitedLinksManager)
        resetVisitedLinksManager();
}

int ProfileAdapter::httpCacheMaxSize() const
{
    return m_httpCacheMaxSize;
}

void ProfileAdapter::setHttpCacheMaxSize(int maxSize)
{
    if (m_httpCacheMaxSize == maxSize)
        return;
    m_httpCacheMaxSize = maxSize;
    if (!m_offTheRecord && !m_profile->m_profileIOData->isClearHttpCacheInProgress())
        m_profile->m_profileIOData->resetNetworkContext();
}

enum class SchemeType { Protected, Overridable, Custom, Unknown };
static SchemeType schemeType(const QByteArray &canonicalScheme)
{
    static const QSet<QByteArray> blacklist{
        QByteArrayLiteral("about"),
        QByteArrayLiteral("blob"),
        QByteArrayLiteral("data"),
        QByteArrayLiteral("javascript"),
        QByteArrayLiteral("qrc"),
        // See also kStandardURLSchemes in url/url_util.cc (through url::IsStandard below)
    };

    static const QSet<QByteArray> whitelist{
        QByteArrayLiteral("gopher"),
    };

    bool standardSyntax = url::IsStandard(canonicalScheme.data(), url::Component(0, canonicalScheme.size()));
    bool customScheme = QWebEngineUrlScheme::schemeByName(canonicalScheme) != QWebEngineUrlScheme();
    bool blacklisted = blacklist.contains(canonicalScheme);
    bool whitelisted = whitelist.contains(canonicalScheme);

    if (whitelisted)
        return SchemeType::Overridable;
    if (blacklisted || (standardSyntax && !customScheme))
        return SchemeType::Protected;
    if (customScheme)
        return SchemeType::Custom;
    return SchemeType::Unknown;
}

QWebEngineUrlSchemeHandler *ProfileAdapter::urlSchemeHandler(const QByteArray &scheme)
{
    return m_customUrlSchemeHandlers.value(scheme.toLower()).data();
}

const QList<QByteArray> ProfileAdapter::customUrlSchemes() const
{
    return m_customUrlSchemeHandlers.keys();
}

void ProfileAdapter::updateCustomUrlSchemeHandlers()
{
    m_profile->ForEachLoadedStoragePartition([](content::StoragePartition *storage_partition) {
        storage_partition->ResetURLLoaderFactories();
    });
}

void ProfileAdapter::removeUrlSchemeHandler(QWebEngineUrlSchemeHandler *handler)
{
    Q_ASSERT(handler);
    bool removedOneOrMore = false;
    auto it = m_customUrlSchemeHandlers.begin();
    while (it != m_customUrlSchemeHandlers.end()) {
        if (it.value() == handler) {
            if (schemeType(it.key()) == SchemeType::Protected) {
                qWarning("Cannot remove the URL scheme handler for an internal scheme: %s", it.key().constData());
                continue;
            }
            it = m_customUrlSchemeHandlers.erase(it);
            removedOneOrMore = true;
            continue;
        }
        ++it;
    }
    if (removedOneOrMore)
        updateCustomUrlSchemeHandlers();
}

void ProfileAdapter::removeUrlScheme(const QByteArray &scheme)
{
    const QByteArray canonicalScheme = scheme.toLower();
    if (schemeType(canonicalScheme) == SchemeType::Protected) {
        qWarning("Cannot remove the URL scheme handler for an internal scheme: %s", scheme.constData());
        return;
    }
    if (m_customUrlSchemeHandlers.remove(canonicalScheme))
        updateCustomUrlSchemeHandlers();
}

void ProfileAdapter::installUrlSchemeHandler(const QByteArray &scheme, QWebEngineUrlSchemeHandler *handler)
{
    Q_ASSERT(handler);
    const QByteArray canonicalScheme = scheme.toLower();
    SchemeType type = schemeType(canonicalScheme);

    if (type == SchemeType::Protected) {
        qWarning("Cannot install a URL scheme handler overriding internal scheme: %s", scheme.constData());
        return;
    }

    if (m_customUrlSchemeHandlers.value(canonicalScheme, handler) != handler) {
        qWarning("URL scheme handler already installed for the scheme: %s", scheme.constData());
        return;
    }

    if (type == SchemeType::Unknown)
        qWarning("Please register the custom scheme '%s' via QWebEngineUrlScheme::registerScheme() "
                 "before installing the custom scheme handler.", scheme.constData());

    m_customUrlSchemeHandlers.insert(canonicalScheme, handler);
    updateCustomUrlSchemeHandlers();
}

void ProfileAdapter::removeAllUrlSchemeHandlers()
{
    if (m_customUrlSchemeHandlers.size() > 1) {
        m_customUrlSchemeHandlers.clear();
        m_customUrlSchemeHandlers.insert(QByteArrayLiteral("qrc"), &m_qrcHandler);
        updateCustomUrlSchemeHandlers();
    }
}

UserResourceControllerHost *ProfileAdapter::userResourceController()
{
    if (!m_userResourceController)
        m_userResourceController.reset(new UserResourceControllerHost);
    return m_userResourceController.data();
}

void ProfileAdapter::setPermission(const QUrl &origin, QWebEnginePermission::PermissionType permissionType,
    QWebEnginePermission::State state, int childId, const std::string &serializedToken)
{
    auto token = PermissionManagerQt::deserializeToken(childId, serializedToken);

    // Check if the frame token is valid, and defer to WebContentsAdapter if so
    auto *rfh = content::RenderFrameHost::FromFrameToken(token);
    if (rfh) {
        static_cast<WebContentsDelegateQt *>(content::WebContents::FromRenderFrameHost(rfh)->GetDelegate())
            ->webContentsAdapter()
                ->setPermission(origin, permissionType, state, childId, serializedToken);
        return;
    }

    // Otherwise, set the permission directly
    static_cast<PermissionManagerQt *>(profile()->GetPermissionControllerDelegate())
        ->setPermission(origin, permissionType, state, token);
}

QWebEnginePermission::State ProfileAdapter::getPermissionState(const QUrl &origin, QWebEnginePermission::PermissionType permissionType,
    int childId, const std::string &serializedToken)
{
    return static_cast<PermissionManagerQt*>(profile()->GetPermissionControllerDelegate())
        ->getPermissionState(origin, permissionType, PermissionManagerQt::deserializeToken(childId, serializedToken));
}

QList<QWebEnginePermission> ProfileAdapter::listPermissions(const QUrl &origin, QWebEnginePermission::PermissionType permissionType)
{
    if (persistentPermissionsPolicy() == ProfileAdapter::PersistentPermissionsPolicy::AskEveryTime)
        return QList<QWebEnginePermission>();

    return static_cast<PermissionManagerQt*>(profile()->GetPermissionControllerDelegate())->listPermissions(origin, permissionType);
}

QString ProfileAdapter::httpAcceptLanguageWithoutQualities() const
{
    QString out;
    auto sep = ""_L1;
    for (auto lang : m_httpAcceptLanguage.tokenize(u',')) {
        out += sep;
        out += *lang.tokenize(u';').begin(); // tokenize() is never empty with KeepEmptyParts!
        sep = ","_L1;
    }
    return out;
}

QString ProfileAdapter::httpAcceptLanguage() const
{
    return m_httpAcceptLanguage;
}

void ProfileAdapter::setHttpAcceptLanguage(const QString &httpAcceptLanguage)
{
    if (m_httpAcceptLanguage == httpAcceptLanguage)
        return;
    m_httpAcceptLanguage = httpAcceptLanguage;

    std::string http_accept_language = httpAcceptLanguageWithoutQualities().toStdString();

    std::vector<content::WebContentsImpl *> list = content::WebContentsImpl::GetAllWebContents();
    for (content::WebContentsImpl *web_contents : list) {
        if (web_contents->GetBrowserContext() == m_profile.data()) {
            blink::RendererPreferences *rendererPrefs = web_contents->GetMutableRendererPrefs();
            rendererPrefs->accept_languages = http_accept_language;
            web_contents->SyncRendererPrefs();
        }
    }

    m_profile->ForEachLoadedStoragePartition(
            [http_accept_language](content::StoragePartition *storage_partition) {
                storage_partition->GetNetworkContext()->SetAcceptLanguage(http_accept_language);
            });
}

QVariant ProfileAdapter::clientHint(ClientHint clientHint) const
{
    blink::UserAgentMetadata &userAgentMetadata = m_profile->m_userAgentMetadata;
    switch (clientHint) {
    case ProfileAdapter::UAArchitecture:
        return QVariant(toQString(userAgentMetadata.architecture));
    case ProfileAdapter::UAPlatform:
        return QVariant(toQString(userAgentMetadata.platform));
    case ProfileAdapter::UAModel:
        return QVariant(toQString(userAgentMetadata.model));
    case ProfileAdapter::UAMobile:
        return QVariant(userAgentMetadata.mobile);
    case ProfileAdapter::UAFullVersion:
        return QVariant(toQString(userAgentMetadata.full_version));
    case ProfileAdapter::UAPlatformVersion:
        return QVariant(toQString(userAgentMetadata.platform_version));
    case ProfileAdapter::UABitness:
        return QVariant(toQString(userAgentMetadata.bitness));
    case ProfileAdapter::UAFullVersionList: {
            QJsonObject ret;
            for (const auto &value : userAgentMetadata.brand_full_version_list)
                ret.insert(toQString(value.brand), QJsonValue(toQString(value.version)));
            return QVariant(ret);
        }
    case ProfileAdapter::UAWOW64:
        return QVariant(userAgentMetadata.wow64);
    case ProfileAdapter::UAFormFactors: {
        QStringList formFactors;
        for (auto formFactor: userAgentMetadata.form_factors) {
            formFactors.append(toQt(formFactor));
        }
        return formFactors;
    }
    default:
        return QVariant();
    }
}

void ProfileAdapter::setClientHint(ClientHint clientHint, const QVariant &value)
{
    blink::UserAgentMetadata &userAgentMetadata = m_profile->m_userAgentMetadata;
    switch (clientHint) {
    case ProfileAdapter::UAArchitecture:
        userAgentMetadata.architecture = value.toString().toStdString();
        break;
    case ProfileAdapter::UAPlatform:
        userAgentMetadata.platform = value.toString().toStdString();
        break;
    case ProfileAdapter::UAModel:
        userAgentMetadata.model = value.toString().toStdString();
        break;
    case ProfileAdapter::UAMobile:
        userAgentMetadata.mobile = value.toBool();
        break;
    case ProfileAdapter::UAFullVersion:
        userAgentMetadata.full_version = value.toString().toStdString();
        break;
    case ProfileAdapter::UAPlatformVersion:
        userAgentMetadata.platform_version = value.toString().toStdString();
        break;
    case ProfileAdapter::UABitness:
        userAgentMetadata.bitness = value.toString().toStdString();
        break;
    case ProfileAdapter::UAFullVersionList: {
        PopulateBrandVersionLists(value.toJsonObject(), userAgentMetadata);
        break;
    }
    case ProfileAdapter::UAWOW64:
        userAgentMetadata.wow64 = value.toBool();
        break;
    case ProfileAdapter::UAFormFactors: {
        userAgentMetadata.form_factors.clear();
        QStringList formFactors = value.toStringList();
        formFactors.sort();
        for (auto formFactor : formFactors)
            userAgentMetadata.form_factors.push_back(formFactor.toStdString());
        break;
    }
    default:
        break;
    }

    std::vector<content::WebContentsImpl *> list = content::WebContentsImpl::GetAllWebContents();
    for (content::WebContentsImpl *web_contents : list) {
        if (web_contents->GetBrowserContext() == m_profile.data()) {
            web_contents->GetMutableRendererPrefs()->user_agent_override.ua_metadata_override = userAgentMetadata;
            web_contents->SyncRendererPrefs();
        }
    }
}

bool ProfileAdapter::clientHintsEnabled()
{
    return m_clientHintsEnabled;
}

void ProfileAdapter::setClientHintsEnabled(bool enabled)
{
    m_clientHintsEnabled = enabled;
}

void ProfileAdapter::resetClientHints()
{
    m_profile->initUserAgentMetadata();
    std::vector<content::WebContentsImpl *> list = content::WebContentsImpl::GetAllWebContents();
    for (content::WebContentsImpl *web_contents : list) {
        if (web_contents->GetBrowserContext() == m_profile.data()) {
            web_contents->GetMutableRendererPrefs()->user_agent_override.ua_metadata_override = m_profile->m_userAgentMetadata;
            web_contents->SyncRendererPrefs();
        }
    }
}

void ProfileAdapter::clearHttpCache()
{
    m_profile->m_profileIOData->clearHttpCache();
}

void ProfileAdapter::setSpellCheckLanguages(const QStringList &languages)
{
#if QT_CONFIG(webengine_spellchecker)
    m_profile->prefServiceAdapter().setSpellCheckLanguages(languages);
#endif
}

QStringList ProfileAdapter::spellCheckLanguages() const
{
#if QT_CONFIG(webengine_spellchecker)
    return m_profile->prefServiceAdapter().spellCheckLanguages();
#else
    return QStringList();
#endif
}

void ProfileAdapter::setSpellCheckEnabled(bool enabled)
{
#if QT_CONFIG(webengine_spellchecker)
    m_profile->prefServiceAdapter().setSpellCheckEnabled(enabled);
#endif
}

bool ProfileAdapter::isSpellCheckEnabled() const
{
#if QT_CONFIG(webengine_spellchecker)
    return m_profile->prefServiceAdapter().isSpellCheckEnabled();
#else
    return false;
#endif
}

bool ProfileAdapter::pushServiceEnabled() const
{
  return m_pushServiceEnabled;
}

void ProfileAdapter::setPushServiceEnabled(bool enabled)
{
    m_pushServiceEnabled = enabled;
}

void ProfileAdapter::addWebContentsAdapterClient(WebContentsAdapterClient *client)
{
    m_webContentsAdapterClients.append(client);
}

void ProfileAdapter::removeWebContentsAdapterClient(WebContentsAdapterClient *client)
{
    m_webContentsAdapterClients.removeAll(client);
}

void ProfileAdapter::releaseAllWebContentsAdapterClients()
{
    while (!m_webContentsAdapterClients.isEmpty())
        m_webContentsAdapterClients.first()->releaseProfile();
}

void ProfileAdapter::resetVisitedLinksManager()
{
    m_visitedLinksManager.reset(new VisitedLinksManagerQt(m_profile.data(), persistVisitedLinks()));
}

void ProfileAdapter::reinitializeHistoryService()
{
    Q_ASSERT(!m_offTheRecord);
    if (ensureDataPathExists()) {
        // remove the associated services first, so we can get new ones (initialized with
        // the new data paths) from the factory
        FaviconServiceFactoryQt::RemoveFromBrowserContext(m_profile.data());
        HistoryServiceFactoryQt::RemoveFromBrowserContext(m_profile.data());

        favicon::FaviconService *faviconService =
                FaviconServiceFactoryQt::GetForBrowserContext(m_profile.data());
        history::HistoryService *historyService = static_cast<history::HistoryService *>(
                HistoryServiceFactoryQt::GetInstance()->GetForBrowserContext(m_profile.data()));
        Q_ASSERT(historyService);
        faviconService->SetHistoryService(historyService);
        if (auto *faviconDriver = FaviconDriverQt::GetForBrowserContext(m_profile.data()))
            faviconDriver->setFaviconService(faviconService);
    } else {
        qWarning("Favicon database is not available for this profile.");
    }
}

QString ProfileAdapter::determineDownloadPath(const QString &downloadDirectory, const QString &suggestedFilename, const time_t &startTime)
{
    QFileInfo suggestedFile(QDir(downloadDirectory).absoluteFilePath(suggestedFilename));
    QString suggestedFilePath = suggestedFile.absoluteFilePath();
    base::FilePath tmpFilePath(toFilePath(suggestedFilePath).NormalizePathSeparatorsTo('/'));

    base::FilePath uniqueFilePath;
    {
        base::ScopedAllowBlocking allowBlock;
        uniqueFilePath = base::GetUniquePath(tmpFilePath);
    }
    if (uniqueFilePath.empty()) {
        base::Time::Exploded exploded;
        base::Time::FromTimeT(startTime).LocalExplode(&exploded);
        std::string suffix = base::StringPrintf(
                    " - %04d-%02d-%02dT%02d%02d%02d.%03d", exploded.year, exploded.month,
                    exploded.day_of_month, exploded.hour, exploded.minute,
                    exploded.second, exploded.millisecond);
        suggestedFilePath = toQt(tmpFilePath.InsertBeforeExtensionASCII(suffix).AsUTF8Unsafe());
    } else if (uniqueFilePath != tmpFilePath) {
        suggestedFilePath = toQt(uniqueFilePath.AsUTF8Unsafe());
    }
    return suggestedFilePath;
}

#if QT_CONFIG(ssl)
QWebEngineClientCertificateStore *ProfileAdapter::clientCertificateStore()
{
    if (!m_clientCertificateStore)
        m_clientCertificateStore = new QWebEngineClientCertificateStore(m_profile->m_profileIOData->clientCertificateStoreData());
    return m_clientCertificateStore;
}

QList<QSslCertificate> ProfileAdapter::additionalTrustedCertificates() const
{
    return m_additionalTrustedCertificates;
}
#endif

static void callbackOnIconAvailableForPageURL(std::function<void (const QIcon &, const QUrl &, const QUrl &)> iconAvailableCallback,
                                              const QUrl &pageUrl,
                                              const favicon_base::FaviconRawBitmapResult &result)
{
    if (!result.is_valid()) {
        iconAvailableCallback(QIcon(), toQt(result.icon_url), pageUrl);
        return;
    }
    QPixmap pixmap(toQt(result.pixel_size));
    pixmap.loadFromData(result.bitmap_data->data(), result.bitmap_data->size());
    iconAvailableCallback(QIcon(pixmap), toQt(result.icon_url), pageUrl);
}

void ProfileAdapter::requestIconForPageURL(const QUrl &pageUrl,
                                           int desiredSizeInPixel,
                                           bool touchIconsEnabled,
                                           std::function<void (const QIcon &, const QUrl &, const QUrl &)> iconAvailableCallback)
{
    DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
    favicon::FaviconService *service = FaviconServiceFactoryQt::GetForBrowserContext(m_profile.data());

    if (!service->HistoryService()) {
        callbackOnIconAvailableForPageURL(iconAvailableCallback, pageUrl,
                                          favicon_base::FaviconRawBitmapResult());
        return;
    }

    favicon_base::IconTypeSet types = { favicon_base::IconType::kFavicon };
    if (touchIconsEnabled) {
        types.insert(favicon_base::IconType::kTouchIcon);
        types.insert(favicon_base::IconType::kTouchPrecomposedIcon);
        types.insert(favicon_base::IconType::kWebManifestIcon);
    }
    service->GetRawFaviconForPageURL(
            toGurl(pageUrl), types, desiredSizeInPixel, true /* fallback_to_host */,
            base::BindOnce(&callbackOnIconAvailableForPageURL, iconAvailableCallback, pageUrl),
            m_cancelableTaskTracker.get());
}

static void callbackOnIconAvailableForIconURL(std::function<void (const QIcon &, const QUrl &)> iconAvailableCallback,
                                              ProfileAdapter *profileAdapter,
                                              const QUrl &iconUrl, int iconType,
                                              int desiredSizeInPixel,
                                              bool touchIconsEnabled,
                                              const favicon_base::FaviconRawBitmapResult &result)
{
    if (!result.is_valid()) {
        // If touch icons are disabled there is no need to try further icon types.
        if (!touchIconsEnabled) {
            iconAvailableCallback(QIcon(), iconUrl);
            return;
        }
        if (static_cast<favicon_base::IconType>(iconType) != favicon_base::IconType::kMax) {
            //Q_ASSERT(profileAdapter->profile());
            favicon::FaviconService *service = FaviconServiceFactoryQt::GetForBrowserContext(profileAdapter->profile());
            service->GetRawFavicon(toGurl(iconUrl),
                                   static_cast<favicon_base::IconType>(iconType + 1),
                                   desiredSizeInPixel,
                                   base::BindOnce(&callbackOnIconAvailableForIconURL, iconAvailableCallback,
                                                  profileAdapter, iconUrl, iconType + 1, desiredSizeInPixel,
                                                  touchIconsEnabled),
                                   profileAdapter->cancelableTaskTracker());
            return;
        }
        iconAvailableCallback(QIcon(), iconUrl);
        return;
    }
    QPixmap pixmap(toQt(result.pixel_size));
    pixmap.loadFromData(result.bitmap_data->data(), result.bitmap_data->size());
    iconAvailableCallback(QIcon(pixmap), toQt(result.icon_url));
}

void ProfileAdapter::requestIconForIconURL(const QUrl &iconUrl,
                                           int desiredSizeInPixel,
                                           bool touchIconsEnabled,
                                           std::function<void (const QIcon &, const QUrl &)> iconAvailableCallback)
{
    DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
    favicon::FaviconService *service = FaviconServiceFactoryQt::GetForBrowserContext(m_profile.data());

    if (!service->HistoryService()) {
        callbackOnIconAvailableForIconURL(iconAvailableCallback,
                                          this,
                                          iconUrl,
                                          static_cast<int>(favicon_base::IconType::kMax), 0,
                                          touchIconsEnabled,
                                          favicon_base::FaviconRawBitmapResult());
        return;
    }
    service->GetRawFavicon(
            toGurl(iconUrl), favicon_base::IconType::kFavicon, desiredSizeInPixel,
            base::BindOnce(&callbackOnIconAvailableForIconURL, iconAvailableCallback, this, iconUrl,
                           static_cast<int>(favicon_base::IconType::kFavicon), desiredSizeInPixel,
                           touchIconsEnabled),
            m_cancelableTaskTracker.get());
}

void ProfileAdapter::setCryptoModulePasswordFunction(std::function<std::string(std::string, std::string, bool)> passwordFunction)
{
    m_cryptoModulePasswordFunction = std::move(passwordFunction);
}

const std::function<std::string(std::string, std::string, bool)> &ProfileAdapter::cryptoModulePasswordFunction() const
{
    return m_cryptoModulePasswordFunction;
}

#if QT_CONFIG(webengine_extensions)
QWebEngineExtensionManager *ProfileAdapter::extensionManager()
{
    return m_extensionManager.get();
}
#endif

} // namespace QtWebEngineCore
